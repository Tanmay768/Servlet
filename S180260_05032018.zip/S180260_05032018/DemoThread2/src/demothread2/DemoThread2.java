
package demothread2;

class MyThread implements Runnable{
    public void doAction(){
        int i;
        System.out.println("Child thread is running...");
        for (i=0;i<10;i++)
            System.out.println(i);
    }
    public void run(){
        doAction();
    }
}
public class DemoThread2 {   
    public static void main(String[] args) {
        MyThread obj=new MyThread();
        Thread th1=new Thread(obj);
        System.out.println("Main thread is running...");
        th1.start();
    }
    
}
