
package demothread4;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
class CountdownTimer extends Thread{
    JTextField tf;
    JLabel lbl;
    JFrame frame;
    public void run(){
        buildGUI();
    }
    public void buildGUI(){
        frame=new JFrame("Countdown Timer");
        JPanel panel=new JPanel();
        lbl=new JLabel("");
        tf=new JTextField(15);
        tf.setEnabled(false);
        Font font=new Font("Verdana",0,18);
        tf.setFont(font);
        tf.setBackground(Color.BLACK);
        panel.setBackground(Color.BLUE);
        frame.add(panel);
        panel.add(tf);
        panel.add(lbl);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        display();
    }
    public void display(){
        for(int i=60;i>=0;i--){
            try{
                Thread.sleep(1000);
                String str=Integer.toString(i);
                tf.setText("     "+str+" seconds to go...");
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
        JOptionPane.showMessageDialog(frame, "Time Up!!");
        tf.setText("");
        tf.setEditable(false);
    }
}
public class DemoThread4 {    
    public static void main(String[] args) {
        CountdownTimer timer=new CountdownTimer();
        timer.start();
    }
    
}
