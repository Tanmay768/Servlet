
package demothread3;


public class DemoThread3 {

    public static void main(String[] args) {
        Thread th2=Thread.currentThread();
        System.out.println("The current thread:"+th2);
        th2.setName("MainThread");
        System.out.println("The current thread:"+th2);
        System.out.println("TThis thread is going to sleep for 5seconds:");
        try{
          Thread.sleep(5000);
        }
        catch(InterruptedException ie){
            System.out.println(ie.getMessage());
        }
        System.out.println("After 5seconds... current thread is executing now...");
    }
    
}
