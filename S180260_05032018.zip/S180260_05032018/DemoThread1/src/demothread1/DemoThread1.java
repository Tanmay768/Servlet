
package demothread1;

class MyThread extends Thread{
    public void doAction(){
        int i;
        System.out.println("Child thread is running...");
        for (i=0;i<10;i++)
            System.out.println(i);
    }
    public void run(){
        doAction();
    }
}
public class DemoThread1 {    
    public static void main(String[] args) {
        
        //creating thread
        MyThread thread1=new MyThread();
        thread1.start();
        System.out.println("Main thread is running...");
        
    }
    
}
