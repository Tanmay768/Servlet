
package demothread5;

import java.awt.Color;
import java.util.Random;
import javax.swing.*;
class Race extends Thread{
    String threadName;
    JLabel lbl;
    JPanel p1,p2,p3;
    JFrame frame;
    public Race(){
        buildGUI();
    }
    public Race(String s){
        super(s);
    }
    
    public void Run(){
        if(Thread.currentThread().getName().equals("ObstacleA")){
            runObstacleA();
        }
        if(Thread.currentThread().getName().equals("ObstacleB")){
            runObstacleB();
        }
        if(Thread.currentThread().getName().equals("ObstacleC")){
            runObstacleC();
        }
    }
    public void buildGUI(){
        frame=new JFrame("Moving objects");
        frame.setVisible(true);
        frame.setSize(400,200);
        frame.setLayout(null);
        lbl=new JLabel("");
        lbl.setBounds(10, 10, 400, 20);
        frame.add(lbl);
        
        p1=new JPanel();
        p1.setSize(20, 20);
        p1.setBackground(Color.red);
        p1.setBounds(10, 40, 20, 20);
        frame.add(p1);
        
        p2=new JPanel();
        p2.setSize(20, 20);
        p2.setBackground(Color.orange);
        p2.setBounds(10, 80, 20, 20);
        frame.add(p2);
        
        p3=new JPanel();
        p3.setSize(20, 20);
        p3.setBackground(Color.yellow);
        p3.setBounds(10, 120, 20, 20);
        frame.add(p3);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void runObstacleA(){
        Random ran=new Random();
        int r=ran.nextInt(1000);
        for(int i=-10;i<400;i++){
            p1.setBounds(i, r, 20, 20);
            try{
                Thread.sleep(5);
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
        runObstacleC();
    }
    public void runObstacleB(){
        Random ran=new Random();
        int m=ran.nextInt(180);
        for(int i=-10;i<400;i++){
            p2.setBounds(i, m, 20, 20);
            try{
                Thread.sleep(11);
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
        runObstacleA();
    }
    public void runObstacleC(){
        Random ran=new Random();
        int s=ran.nextInt(10);
        for(int i=-10;i<400;i++){
            p3.setBounds(i, s, 20, 20);
            try{
                Thread.sleep(10);
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
        runObstacleB();
    }
}
public class DEmoThread5 {

    
    public static void main(String[] args) {
        Race obj=new Race();
        Thread Obstacle1=new Thread(obj);
        Thread Obstacle2=new Thread(obj);
        Thread Obstacle3=new Thread(obj);
        Obstacle1.setName("ObstacleA");
        Obstacle2.setName("ObstacleB");
        Obstacle3.setName("ObstacleC");
        Obstacle1.start();
        Obstacle2.start();
        Obstacle3.start();
    }
    
}
