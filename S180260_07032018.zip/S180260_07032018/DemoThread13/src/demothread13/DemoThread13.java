
package demothread13;

import java.util.concurrent.locks.*;

class ThreadDemo implements Runnable{
    ReadWriteLock rwl;

    public ThreadDemo(ReadWriteLock rwl) {
        this.rwl = rwl;
    }
    
    public void run(){
        rwl.readLock().lock();
        System.out.println(Thread.currentThread().getName()+" has acquired read lock.");
        try{
            Thread.sleep(4000);
        }
        catch(InterruptedException ie){
            System.out.println(ie.getMessage());
        }
        System.out.println(Thread.currentThread().getName()+" has released read lock.");
        rwl.readLock().unlock();
    }
}
public class DemoThread13 {    
    public static void main(String[] args) {
        ReadWriteLock obj=new ReentrantReadWriteLock();
        ThreadDemo td=new ThreadDemo(obj);
        Thread th1=new Thread(td,"Thread1");
        Thread th2=new Thread(td,"Thread2");
        th1.start();
        th2.start();
    }
    
}
