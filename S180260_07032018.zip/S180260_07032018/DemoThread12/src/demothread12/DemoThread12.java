
package demothread12;

import java.util.concurrent.atomic.*;
public class DemoThread12 {    
    public static void main(String[] args) {
        AtomicInteger i=new AtomicInteger(24);
        System.out.println(i.get());
        i.getAndDecrement();//read and then decrease the value of i variable
        System.out.println("After decrease: "+i.get());
        i.compareAndSet(23, 45);
        System.out.println("After compare and replace: "+i.get());
        
    }
    
}
