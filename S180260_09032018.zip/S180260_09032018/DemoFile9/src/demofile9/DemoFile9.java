
package demofile9;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_DELETE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;


public class DemoFile9 {
    Path path=null;
    WatchService service;
    
    public void InitService()
    {
        path=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\All_files");
        try{
            //1. create watch service
            service=FileSystems.getDefault().newWatchService();
            //2. register path to monitor by the watch service
            path.register(service, ENTRY_CREATE,ENTRY_DELETE,ENTRY_MODIFY);
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    public void MonitorDir(){
        WatchKey key=null;
        //3. wait to event occur
        while(true){
            try{
                //4. retrieve the watch key
                key=service.take();
                //5. retrieve the events for the key
                for(WatchEvent event:key.pollEvents()){
                    Kind kind=event.kind();
                    System.out.println("The event is occured on "+event.context().toString()+" is "+kind);
                }
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
            //6. reset the key
            boolean resetKey=key.reset();
            if(!resetKey)
                break;
        }
    }
    
    public static void main(String[] args) {
        DemoFile9 obj=new DemoFile9();
        obj.InitService();
        obj.MonitorDir();
    }
    
}
