
package demofile7;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DemoFile7 {
    
    public static void main(String[] args) {
        Path path=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\NewPath\\secondFile.txt");
        try{
            Files.deleteIfExists(path);
            System.out.println("file deleted...");
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    
}
