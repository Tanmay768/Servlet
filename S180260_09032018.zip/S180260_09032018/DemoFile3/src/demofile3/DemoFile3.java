
package demofile3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
public class DemoFile3 {

    public static void main(String[] args) {
        //Path is interface and Paths is class are used to define path
        Path path=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\NewPath");
        
        try{
            //checking for existing of requested directory
            //checking for the path is absolute
            if(!Files.exists(path, LinkOption.NOFOLLOW_LINKS)){
                //creating directory
                Files.createDirectory(path);
                System.out.println("Directory created");
            }
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
        
        Path newFile=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\secondFile.txt");
        try{
            Files.createFile(newFile);
            System.out.println("File created");
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
        
    }
    
}
