package demofile10;

import java.io.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

class FileReadWrite{
    public void ReadData(){
        Path path=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\Firstpath\\hello.txt");
        Charset charset=Charset.forName("US-ASCII");
        try{
            BufferedReader reader=Files.newBufferedReader(path, charset);
            String content=null;
            while((content=reader.readLine())!=null){
                System.out.println(content);
            }
            reader.close();
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    public void WriteData(){
        try{
            BufferedReader rd=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Accept any content:");
            String content=rd.readLine();
            Path path=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\"
                    + "Java\\All_files\\Firstpath\\hello.txt");
            Charset charset=Charset.forName("US-ASCII");
            BufferedWriter bw=null;
            if(!Files.exists(path)){
                bw=Files.newBufferedWriter(path, charset, 
                    StandardOpenOption.CREATE);
                bw.write(content);
            }
            bw=Files.newBufferedWriter(path, charset, 
                    StandardOpenOption.APPEND);
                bw.append(content);
            bw.close();
            System.out.println("File write is done");
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
}

public class DemoFile10 {

   
    public static void main(String[] args) {
        FileReadWrite frw=new FileReadWrite();
        frw.WriteData();
        frw.ReadData();
    }
    
}
