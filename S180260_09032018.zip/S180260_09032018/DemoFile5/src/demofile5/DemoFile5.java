
package demofile5;

import java.io.IOException;
import java.nio.file.*;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
public class DemoFile5 {    
    public static void main(String[] args) {
        Path source=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\output.txt");
        
        Path target=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\NewPath\\output.txt");
        
        try{
            Files.move(source, target, REPLACE_EXISTING);
            System.out.println("File moved...");
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    
}
