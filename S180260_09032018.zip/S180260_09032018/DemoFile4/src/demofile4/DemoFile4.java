
package demofile4;

import java.nio.file.*;
public class DemoFile4 {

    public static void main(String[] args) {
        Path path=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\secondFile.txt");
        System.out.println(path.getFileName());
        System.out.println(path.getFileSystem());
        System.out.println(path.getName(1));
        System.out.println(path.getNameCount());
        System.out.println(path.getParent());
        System.out.println(path.getRoot());
        
    }
    
}
