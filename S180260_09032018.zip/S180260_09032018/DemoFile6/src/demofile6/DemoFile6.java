
package demofile6;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardCopyOption.COPY_ATTRIBUTES;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;


public class DemoFile6 {

  
    public static void main(String[] args) {
        Path source=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\secondFile.txt");
        
        Path target=Paths.get("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\"
                + "All_files\\NewPath\\secondFile.txt");
        
        try{
            Files.copy(source, target, REPLACE_EXISTING,COPY_ATTRIBUTES);
            System.out.println("File copied...");
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    
}
