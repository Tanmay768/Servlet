
package demofile1;

import java.io.*;
class FileReadWrite{
    File file=new File("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\Java\\All_files"
            + "\\NewFile.txt");
    
    public void WriteData(){
        String content;
        try(FileOutputStream fos=new FileOutputStream(file)){
            //accepting data from user
            BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter any string to write to the file:");
            content=reader.readLine();
            //checking whether file exist
            //if file does not exist then will create new file
            if(!file.exists()){
                file.createNewFile();
            }
            //converting string value into array of bytes
            byte[] contentInBytes=content.getBytes();
            //Writing bytes to the stream
            fos.write(contentInBytes);
            //write the last bytes from the buffer and then make free the buffer
            fos.flush();
            fos.close();
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    public void ReadData(){
        int i;
        char ch;
        try(FileInputStream fis=new FileInputStream(file)){
            //checking end of file
            while((i=fis.read())!=-1){
                ch=(char)i;
                System.out.print(ch);
            }
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
}
public class DemoFile1 {    
    public static void main(String[] args) {
        FileReadWrite obj=new FileReadWrite();
        obj.WriteData();
        System.out.println("Successfully file has been created");
        System.out.println("Reading from file");
        obj.ReadData();
    }
    
}
