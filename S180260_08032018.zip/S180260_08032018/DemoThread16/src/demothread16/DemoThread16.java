
package demothread16;

import java.util.Random;
import java.util.concurrent.*;
class FindMax extends RecursiveTask<Integer>{
    final int[] arr;
    final int low,high;

    public FindMax(int[] arr, int low, int high) {
        this.arr = arr;
        this.low = low;
        this.high = high;
    }

    public FindMax(int[] arr) {
        this(arr,0,arr.length);
    }
    public Integer compute(){
        int length=high-low;
       
        if(length<100){
            return computeDirectly();
        }
        int mid=length/2;
        FindMax leftArr=new FindMax(arr,low,low+mid);
        leftArr.fork();
        FindMax rightArr=new FindMax(arr,low+mid,high);
        return Math.max(rightArr.compute(), leftArr.join());
    }
    public Integer computeDirectly(){
        System.out.println(Thread.currentThread()+" is processing from "+low+" to "+high);
        int max=Integer.MIN_VALUE;
        for(int num=low;num<high;num++){
            if(arr[num]>max)
                max=arr[num];
        }
        return max;
    }
}
public class DemoThread16 {
   
    public static void main(String[] args) {
        Random ran=new Random();
        int[] arr=new int[200];
        for(int i=0;i<200;i++){
            arr[i]=ran.nextInt(350);
        }
        ForkJoinPool pool1=new ForkJoinPool(4);
        FindMax fmax=new FindMax(arr);
        System.out.println("The maximum value is "+pool1.invoke(fmax));
    }
    
}
