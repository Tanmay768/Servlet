
package demothread14;

import java.util.concurrent.*;

class ThreadDemo implements Runnable{
    String nameTask;
    public ThreadDemo(String nameTask){
        this.nameTask=nameTask;
    }
    public void run(){
        System.out.println("Task Name "+nameTask+" running by "+Thread.currentThread().getName());
    }
}
public class DemoThread14 {
    
    public static void main(String[] args) {
       ThreadDemo task1=new ThreadDemo("My Task1");
       ThreadDemo task2=new ThreadDemo("My Task2");
       ThreadDemo task3=new ThreadDemo("My Task3");
       ThreadDemo task4=new ThreadDemo("My Task4");
        
       ExecutorService serve=Executors.newCachedThreadPool();
       serve.execute(task1);
       serve.execute(task2);
       serve.execute(task3);
       serve.execute(task4);
       serve.shutdown();
       
       if(serve.isShutdown()){
           System.out.println("All tasks of EXecutor are completed...");
       }
       
    }
    
}
