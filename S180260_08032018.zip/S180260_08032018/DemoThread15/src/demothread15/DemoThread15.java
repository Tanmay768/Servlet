
package demothread15;

import java.util.concurrent.*;

class ThreadDemo implements Callable{
     String nameTask;
    public ThreadDemo(String nameTask){
        this.nameTask=nameTask;
    }
    public String call(){
        System.out.println("Task Name "+nameTask+" running by "+Thread.currentThread().getName());
        return nameTask;
    }
}
public class DemoThread15 {

   
    public static void main(String[] args) {
        ThreadDemo task1=new ThreadDemo("My Task1");
       ThreadDemo task2=new ThreadDemo("My Task2");
       ThreadDemo task3=new ThreadDemo("My Task3");
       ThreadDemo task4=new ThreadDemo("My Task4");
       ExecutorService serve=Executors.newFixedThreadPool(4);
       
       Future<String> future1=serve.submit(task1);
       Future<String> future2=serve.submit(task2);
       Future<String> future3=serve.submit(task3);
       Future<String> future4=serve.submit(task4);
       
    }
    
}
