
package demofile2;
import java.io.*;
class FileReadWrite{
    String content;
    public void WriteData(){
        try{
            BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));
            Writer wr=new FileWriter("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\"
                    + "Java\\All_files\\output.txt");
            System.out.println("Enter any string:");
            content=buffer.readLine();
            wr.write(content);
            wr.close();
            System.out.println("Completed file writing...");
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
    public void ReadData(){
        try{
            Reader rd=new FileReader("D:\\Lopa\\Current_Notes\\S180260_PGJS1\\"
                    + "Java\\All_files\\output.txt");
            int data=rd.read();
            while(data!=-1){
                System.out.print((char)data);
                data=rd.read();
            }
        }
        catch(IOException ioe){
            System.out.println(ioe.getMessage());
        }
    }
}
public class DemoFile2 {

    public static void main(String[] args) {
        FileReadWrite frw=new FileReadWrite();
        frw.WriteData();
        frw.ReadData();
    }
    
}
