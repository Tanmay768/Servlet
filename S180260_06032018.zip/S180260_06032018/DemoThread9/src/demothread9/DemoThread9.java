
package demothread9;

class ThreadDemo implements Runnable{
    public void run(){
        int i;
        synchronized(this){
            for(i=0;i<100;i++){
                System.out.print(i+"    ");
            }
        }
    }
}
public class DemoThread9 {    
    public static void main(String[] args) {
        ThreadDemo obj=new ThreadDemo();
        Thread th1=new Thread(obj);
        Thread th2=new Thread(obj);
        Thread th3=new Thread(obj);
        th1.start();
        th2.start();
        th3.start();
    }
    
}
