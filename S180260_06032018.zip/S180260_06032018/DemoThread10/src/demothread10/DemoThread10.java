
package demothread10;

class SynchronizedClass{
    static int var=0;
    public synchronized static void increase(){
        for(var=0;var<100;var++){
            System.out.println("var: "+var);
        }
    }
    public synchronized static void decrease(){
        for(var=100;var>=0;var--){
            System.out.println("var: "+var);
        }
    }
}
class MyThread1 extends Thread{
    public void run(){
        SynchronizedClass.increase();
        SynchronizedClass.decrease();
    }
}
class MyThread2 extends Thread{
    public void run(){
        SynchronizedClass.increase();
        SynchronizedClass.decrease();
    }
}
class MyThread3 extends Thread{
    public void run(){
        SynchronizedClass.increase();
        SynchronizedClass.decrease();
    }
}
public class DemoThread10 {   
    public static void main(String[] args) {
        MyThread1 th1=new MyThread1();
        MyThread2 th2=new MyThread2();
        MyThread3 th3=new MyThread3();
        th1.start();
        th2.start();
        th3.start();
    }
    
}
