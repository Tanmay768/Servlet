
package demothread6;

class ThreadDemo extends Thread{
    public void run(){
        System.out.println("Child Thread is running...");
        try{
            Thread.sleep(3000);
        }
        catch(InterruptedException ie){
            System.out.println(ie.getMessage());
        }
        System.out.println("Ending child thread operation...");
    }
}
public class DemoThread6 {

    public static void main(String[] args) {
        ThreadDemo th1=new ThreadDemo();
        ThreadDemo th2=new ThreadDemo();
        th1.start();
        th2.start();
        System.out.println(th1.isAlive());
        System.out.println(th2.isAlive());
    }
    
}
