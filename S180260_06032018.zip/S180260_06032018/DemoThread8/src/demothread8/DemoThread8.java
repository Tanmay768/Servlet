
package demothread8;
class Process1 implements Runnable{
    public void run(){
        System.out.println("Process1 is running...");
    }
}
class Process2 implements Runnable{
    public void run(){
        System.out.println("Process2 is running...");
    }
}
class Process3 implements Runnable{
    public void run(){
        System.out.println("Process3 is running...");
    }
}
public class DemoThread8 {    
    public static void main(String[] args) {
        System.out.println("Main Thread is creating child threads...");
        Thread th1=new Thread(new Process1());
        Thread th2=new Thread(new Process2());
        Thread th3=new Thread(new Process3());
        System.out.println("Main Thread is starting child threads...");
        th1.setPriority(Thread.MIN_PRIORITY);
        th2.setPriority(Thread.MAX_PRIORITY);
        th3.setPriority(Thread.NORM_PRIORITY);
        th1.start();
        th2.start();
        th3.start();
        System.out.println("Prority of Thread1: "+th1.getPriority());
        System.out.println("Prority of Thread2: "+th2.getPriority());
        System.out.println("Prority of Thread2: "+th3.getPriority());
        System.out.println("Ending main thread");
    }
    
}
