
package demothread11;
class Message{
   private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Message(String message) {
        this.message = message;
    }   
}
class Waiter implements Runnable{
    private Message msg;
    public Waiter(Message m){
        msg=m;
    }
    public void run(){
        String name=Thread.currentThread().getName();
        synchronized(msg){
            try{
                System.out.println(name+" waiting thread to notified at time: "+System.currentTimeMillis());
                msg.wait();
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
            System.out.println(name+" waiter thread got notified at time: "+System.currentTimeMillis());
            System.out.println(name+" processed "+msg.getMessage());
        }
    }
}
class Notifier implements Runnable{
    private Message msg;
    public Notifier(Message m){
        msg=m;
    }
    public void run(){
        String name=Thread.currentThread().getName();
       System.out.println(name+  " started");
            try{
                Thread.sleep(1000);
                synchronized(msg){
                    msg.setMessage(name+ " Notifier work done");
                    //msg.notify();
                    msg.notifyAll();
                }
            }
            catch(InterruptedException ie){
                System.out.println(ie.getMessage());
            }
    }
}
public class DemoThread11 {

    
    public static void main(String[] args) {
        Message msg=new Message("Process It");
        Waiter w1=new Waiter(msg);
        Thread th1=new Thread(w1,"Waiter1");
        th1.start();
        
        Waiter w2=new Waiter(msg);
        Thread th2=new Thread(w2,"Waiter2");
        th2.start();
        
        Notifier n=new Notifier(msg);
        Thread th3=new Thread(n,"Notifier");
        th3.start();
        
        System.out.println("Thread(s) are started");
    }
    
}
